import { Equivocation } from "./module/types/cosmos/evidence/v1beta1/evidence";
export { Equivocation };
declare const _default;
export default _default;
